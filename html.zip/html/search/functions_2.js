var searchData=
[
  ['getcompressedoutput_0',['getcompressedOutput',['../class_first_compressor_audio_processor.html#a1ff50cff6ac6d38486c9515ce17edbac',1,'FirstCompressorAudioProcessor']]],
  ['getgainreduction_1',['getGainReduction',['../class_first_compressor_audio_processor.html#acbcf61c9368fac4dfa1f8320ded4b04b',1,'FirstCompressorAudioProcessor']]],
  ['getpeakdetectorobjectl_2',['getPeakDetectorObjectL',['../class_first_compressor_audio_processor.html#a929d8d9405fca43d8eb4178e29dcfa40',1,'FirstCompressorAudioProcessor']]],
  ['getpeakvaluel_3',['getPeakValueL',['../class_first_compressor_audio_processor.html#a72dd86a1b15bda808452a5aa8c820298',1,'FirstCompressorAudioProcessor']]],
  ['getpeakvaluer_4',['getPeakValueR',['../class_first_compressor_audio_processor.html#a73687b4c8fe6671ee9ce1255a7c78add',1,'FirstCompressorAudioProcessor']]]
];
