var searchData=
[
  ['knobattackstrip_0',['knobAttackStrip',['../class_other_look_and_feel.html#aff2e34b068a5e57d187ce878e3650e79',1,'OtherLookAndFeel']]],
  ['knobthresholdstrip_1',['knobThresholdStrip',['../class_compressor_look_and_feel.html#aa12c5fa64d8b62872c7370d53744a94b',1,'CompressorLookAndFeel']]]
];
