var searchData=
[
  ['peakdetector_0',['PeakDetector',['../class_peak_detector.html',1,'']]],
  ['peakdetectorgui_1',['PeakDetectorGUI',['../class_peak_detector_g_u_i.html',1,'']]]
];
