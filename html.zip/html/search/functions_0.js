var searchData=
[
  ['compress_0',['compress',['../class_first_compressor_audio_processor.html#aa757f8771667906284113814da1593b6',1,'FirstCompressorAudioProcessor']]],
  ['createparameters_1',['createParameters',['../class_first_compressor_audio_processor.html#a3c81d57e9b1d7ea1cd143b8fa18c7d02',1,'FirstCompressorAudioProcessor']]]
];
