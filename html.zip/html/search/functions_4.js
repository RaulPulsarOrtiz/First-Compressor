var searchData=
[
  ['paint_0',['paint',['../class_vertical_meter.html#aa7775d0df5ba56bbcd2f7ac440882ad1',1,'VerticalMeter']]],
  ['process_1',['process',['../class_peak_detector.html#a3b98f85aa6df6c02b285e851d9c0aac8',1,'PeakDetector']]]
];
